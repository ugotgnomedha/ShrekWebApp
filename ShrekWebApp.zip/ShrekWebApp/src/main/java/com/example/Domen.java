package com.example;

public class Domen {

    private String domenName;
    private Integer domenCount;

    public Domen(String domenName, Integer domenCount) {
        this.domenName = domenName;
        this.domenCount = domenCount;
    }

}
